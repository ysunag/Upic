CREATE VIEW `x$schema_flattened_keys` AS
  SELECT
    `statistics`.`TABLE_SCHEMA`                      AS `TABLE_SCHEMA`,
    `statistics`.`TABLE_NAME`                        AS `TABLE_NAME`,
    `statistics`.`INDEX_NAME`                        AS `INDEX_NAME`,
    max(`statistics`.`NON_UNIQUE`)                   AS `non_unique`,
    max(if((`statistics`.`SUB_PART` IS NULL), 0, 1)) AS `subpart_exists`,
    group_concat(`statistics`.`COLUMN_NAME` ORDER BY `statistics`.`SEQ_IN_INDEX` ASC SEPARATOR
                 ',')                                AS `index_columns`
  FROM `information_schema`.`STATISTICS`
  WHERE ((`statistics`.`INDEX_TYPE` = 'BTREE') AND (`statistics`.`TABLE_SCHEMA` NOT IN
                                                    ('mysql', 'sys', 'INFORMATION_SCHEMA', 'PERFORMANCE_SCHEMA')))
  GROUP BY `statistics`.`TABLE_SCHEMA`, `statistics`.`TABLE_NAME`, `statistics`.`INDEX_NAME`;

